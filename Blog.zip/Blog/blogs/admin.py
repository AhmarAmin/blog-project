from django.contrib import admin
from .models import Author,BlogPost

admin.site.register(Author)
admin.site.register(BlogPost)
